#ifndef __DMA_H
#define	__DMA_H	   
#include "sys.h"

#define PerToMem 0x00
#define MemToPer 0x40

void DMA_Config(DMA_Stream_TypeDef *DMA_Streamx,u32 chx,u32 par,u32 mar,u16 ndtr,u32 distination);//����DMAx_CHx
void SinWave_DMA_Config(void);
void SinWave_TIM_Config(u16 arr,u16 psc);
#endif
