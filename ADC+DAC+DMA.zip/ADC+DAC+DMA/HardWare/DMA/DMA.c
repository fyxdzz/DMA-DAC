#include "DMA.h"

const u16 Sine12bit2[500] = {  
                      2048,2073,2099,2125,2150,2176,2202,2227,2253,2279,2304,2330,2355,2380,
					2406,2431,2456,2482,2507,2532,2557,2582,2606,2631,2656,2680,2705,2729,2753,
					2777,2801,2825,2849,2872,2896,2919,2942,2966,2988,3011,3034,3056,3079,3101,
					3123,3145,3166,3188,3209,3230,3251,3272,3292,3313,3333,3353,3372,3392,3411,
					3430,3449,3468,3486,3504,3522,3540,3558,3575,3592,3609,3625,3641,3657,3673,
					3689,3704,3719,3734,3748,3762,3776,3790,3803,3816,3829,3842,3854,3866,3878,
					3889,3900,3911,3921,3932,3942,3951,3961,3970,3978,3987,3995,4003,4010,4017,
					4024,4031,4037,4043,4048,4054,4059,4063,4068,4072,4075,4079,4082,4085,4087,
					4089,4091,4092,4094,4094,4095,4095,4095,4094,4094,4092,4091,4089,4087,4085,
					4082,4079,4075,4072,4068,4063,4059,4054,4048,4043,4037,4031,4024,4017,4010,
					4003,3995,3987,3978,3970,3961,3951,3942,3932,3921,3911,3900,3889,3878,3866,
					3854,3842,3829,3816,3803,3790,3776,3762,3748,3734,3719,3704,3689,3673,3657,
					3641,3625,3609,3592,3575,3558,3540,3522,3504,3486,3468,3449,3430,3411,3392,
					3372,3353,3333,3313,3292,3272,3251,3230,3209,3188,3166,3145,3123,3101,3079,
					3056,3034,3011,2988,2966,2943,2919,2896,2872,2849,2825,2801,2777,2753,2729,
					2705,2680,2656,2631,2606,2582,2557,2532,2507,2482,2456,2431,2406,2381,2355,
					2330,2304,2279,2253,2227,2202,2176,2150,2125,2099,2073,2048,2022,1996,1970,
					1945,1919,1893,1868,1842,1816,1791,1765,1740,1715,1689,1664,1639,1613,1588,
					1563,1538,1513,1489,1464,1439,1415,1390,1366,1342,1318,1294,1270,1246,1223,
					1199,1176,1153,1129,1107,1084,1061,1039,1016,994,972,950,929,907,886,865,
					844,823,803,782,762,742,723,703,684,665,646,627,609,591,573,555,537,520,
					503,486,470,454,438,422,406,391,376,361,347,333,319,305,292,279,266,253,
					241,229,217,206,195,184,174,163,153,144,134,125,117,108,100,92,85,78,71,
					64,58,52,47,41,36,32,27,23,20,16,13,10,8,6,4,3,1,1,0,0,0,1,1,3,4,6,8,10,
					13,16,20,23,27,32,36,41,47,52,58,64,71,78,85,92,100,108,117,125,134,144,
					153,163,174,184,195,206,217,229,241,253,266,279,292,305,319,333,347,361,
					376,391,406,422,438,454,470,486,503,520,537,555,573,591,609,627,646,665,
					684,703,723,742,762,782,803,823,844,865,886,907,929,950,972,994,1016,1039,
					1061,1084,1107,1129,1153,1176,1199,1223,1246,1270,1294,1318,1342,1366,1390,
					1415,1439,1464,1489,1513,1538,1563,1588,1613,1639,1664,1689,1715,1740,1765,
					1791,1816,1842,1868,1893,1919,1945,1970,1996,2022}; 
u16 DualSine12bit[500];  
/*��������*/
void DMA_Config(DMA_Stream_TypeDef *DMA_Streamx,u32 chx,u32 par,u32 mar,u16 ndtr,u32 distination)
{ 
 
	DMA_InitTypeDef  DMA_InitStructure;
	
	if((u32)DMA_Streamx>(u32)DMA2)//�õ���ǰstream������DMA2����DMA1
	{
	  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2,ENABLE);//DMA2ʱ��ʹ�� 
		
	}else 
	{
	  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1,ENABLE);//DMA1ʱ��ʹ�� 
	}
  DMA_DeInit(DMA_Streamx);
	
	while (DMA_GetCmdStatus(DMA_Streamx) != DISABLE){}//�ȴ�DMA������ 
	
  /* ���� DMA Stream */
  DMA_InitStructure.DMA_Channel = chx;  //ͨ��ѡ��
  DMA_InitStructure.DMA_PeripheralBaseAddr = par;//DMA�����ַ
  DMA_InitStructure.DMA_Memory0BaseAddr = mar;//DMA �洢��0��ַ
  DMA_InitStructure.DMA_DIR = distination;//���䷽��
  DMA_InitStructure.DMA_BufferSize = ndtr;//���ݴ����� 
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;//���������ģʽ
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;//�洢������ģʽ
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;//�������ݳ���:16λ
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;//�洢�����ݳ���:16λ
  DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;// ʹ��ѭ��ģʽ 
  DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;//�е����ȼ�
  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;         
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_Full;
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;//�洢��ͻ�����δ���
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;//����ͻ�����δ���
  DMA_Init(DMA_Streamx, &DMA_InitStructure);//��ʼ��DMA Stream

} 

void SinWave_DMA_Config()
{
	u32 Idx;
	for (Idx = 0; Idx < 500; Idx++)  
	{  
		DualSine12bit[Idx] = (Sine12bit2[Idx] << 16) + (Sine12bit2[Idx]);  
	} 
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1,ENABLE);//DMA1ʱ��ʹ�� 
	DMA1_Stream6->PAR=(u32)&(DAC->DHR12R2);		//DAC��ַ
	DMA1_Stream6->M0AR=(u32)DualSine12bit;		//DMA ???0??
	DMA1_Stream6->NDTR=500;		//??500???
	DMA1_Stream6->CR=0;			//?????CR???? 
	
	DMA1_Stream6->CR|=1<<6;		//????????
	DMA1_Stream6->CR|=1<<8;		//????
	DMA1_Stream6->CR|=0<<9;		//???????
	DMA1_Stream6->CR|=1<<10;		//???????
	
	DMA1_Stream6->CR|=1<<11;		//??????:16?
	DMA1_Stream6->CR|=1<<13;		//???????:16?
	DMA1_Stream6->CR|=1<<16;		//?????
	DMA1_Stream6->CR|=0<<21;		//????????
	DMA1_Stream6->CR|=0<<23;		//?????????
	DMA1_Stream6->CR|=(u32)7<<25;//????(5??)
}


//???TIM4
void SinWave_TIM_Config(u16 arr,u16 psc)
{
	RCC->APB1ENR|=1<<2;	//TIM2????    
 	TIM4->ARR=arr;  	//?????????? 
	TIM4->PSC=psc;  	//????	  
	TIM4->CR2|=2<<4;      //????????????(TRGO)  
	TIM4->CR1|=0x01;    //?????4
}

