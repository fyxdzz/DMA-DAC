#ifndef __TIM_H
#define	__TIM_H	   
#include "sys.h"

#define sendbuffsize 36
void TIM6_Config(void);
#endif
