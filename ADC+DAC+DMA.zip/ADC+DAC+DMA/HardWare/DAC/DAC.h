#ifndef __DAC_H
#define	__DAC_H	   
#include "sys.h"

#define DAC_DHR12R2_ADDRESS    0x40007414
void Dac_Init(void);

void DAC_Ch2_TriangleConfig(void);
void DAC_Ch2_SineWaveConfig(void);
#endif
