#include "stm32f4xx.h"
#include "usart.h"
#include "delay.h"
#include "adc.h"
#include "TIM.h"
#include "dac.h"
#include "dma.h"

u16 sendbuff[sendbuffsize];//����������tim.h
u16 sinbuff[32]=
	{
											2047, 2447, 2831, 3185, 3498, 3750, 3939, 4056, 4095, 4056,

                      3939, 3750, 3495, 3185, 2831, 2447, 2047, 1647, 1263, 909,

                      599, 344, 155, 38, 0, 38, 155, 344, 599, 909, 1263, 1647
	};

u16 i=0;
int main(void)
{

	
  /* Preconfiguration before using DAC----------------------------------------*/
  GPIO_InitTypeDef GPIO_InitStructure;

  /* DMA1 clock enable */
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1, ENABLE);
  /* GPIOA clock enable (to be used with DAC) */
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);                         
  /* DAC Periph clock enable */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);

  /* DAC channel 1 & 2 (DAC_OUT1 = PA.4)(DAC_OUT2 = PA.5) configuration */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_Init(GPIOA, &GPIO_InitStructure);

  /* TIM6 Configuration ------------------------------------------------------*/
  TIM6_Config();  
	DAC_DeInit();
	DAC_Ch2_SineWaveConfig();
	while(1)
	{
			
	}
}



